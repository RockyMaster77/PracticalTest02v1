package com.example.practicaltest02v1;

import android.util.Log;
import org.json.JSONArray;
import org.json.JSONException;
import java.io.*;
import java.net.*;

public class CommunicationThread extends Thread {
    private final Socket socket;

    public CommunicationThread(Socket socket) {
        this.socket = socket;
    }

    @Override
    public void run() {
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
             PrintWriter writer = new PrintWriter(socket.getOutputStream(), true)) {

            // 1. Citim prefixul de la client
            String prefix = reader.readLine();
            if (prefix == null || prefix.isEmpty()) return;

            // 2. Cerere HTTP la Google
            String urlStr = "https://www.google.com/complete/search?client=chrome&q=" + URLEncoder.encode(prefix, "UTF-8");
            HttpURLConnection conn = (HttpURLConnection) new URL(urlStr).openConnection();
            conn.setRequestProperty("User-Agent", "Mozilla/5.0");

            BufferedReader httpReader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = httpReader.readLine()) != null) sb.append(line);
            httpReader.close();

            // 3. Parsare JSON (format: ["prefix", ["sugestie1", "sugestie2"], ...])
            String result;
            try {
                JSONArray jsonArray = new JSONArray(sb.toString());
                JSONArray suggestions = jsonArray.getJSONArray(1);
                StringBuilder formattedSuggestions = new StringBuilder();
                for (int i = 0; i < suggestions.length(); i++) {
                    formattedSuggestions.append(suggestions.getString(i)).append(i < suggestions.length() - 1 ? ", " : "");
                }
                result = formattedSuggestions.toString();
            } catch (JSONException e) {
                result = "Eroare parsare date";
            }

            // 4. Trimitem rezultatul curat înapoi la client
            writer.println(result);
            socket.close();

        } catch (IOException e) {
            Log.e("COMM", "Error: " + e.getMessage());
        }
    }
}