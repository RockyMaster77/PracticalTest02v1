package com.example.practicaltest02v1;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class PracticalTest02v1MainActivity extends AppCompatActivity {

    private EditText prefixEditText, portEditText;
    private Button getAutocompleteButton, startServerButton;
    private TextView resultTextView;
    private ServerThread serverThread;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_practical_test02v1_main);

        // Mapare UI
        prefixEditText = findViewById(R.id.prefix_edit_text);
        portEditText = findViewById(R.id.server_port_edit_text);
        getAutocompleteButton = findViewById(R.id.get_autocomplete_button);
        startServerButton = findViewById(R.id.start_server_button);
        resultTextView = findViewById(R.id.result_text_view);

        // Buton START SERVER
        startServerButton.setOnClickListener(v -> {
            String portStr = portEditText.getText().toString();
            if (portStr.isEmpty()) {
                Toast.makeText(this, "Introdu portul!", Toast.LENGTH_SHORT).show();
                return;
            }
            int port = Integer.parseInt(portStr);

            if (serverThread == null || !serverThread.isAlive()) {
                serverThread = new ServerThread(port);
                serverThread.start();
                Toast.makeText(this, "Server pornit pe " + port, Toast.LENGTH_SHORT).show();
            }
        });

        // Buton CLIENT REQUEST
        getAutocompleteButton.setOnClickListener(v -> {
            String portStr = portEditText.getText().toString();
            String prefix = prefixEditText.getText().toString();

            if (portStr.isEmpty() || prefix.isEmpty()) {
                Toast.makeText(this, "Completează toate câmpurile!", Toast.LENGTH_SHORT).show();
                return;
            }

            resultTextView.setText("Se caută...");

            new ClientThread("127.0.0.1", Integer.parseInt(portStr), prefix, resultTextView).start();
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (serverThread != null) {
            serverThread.stopServer();
        }
    }
}