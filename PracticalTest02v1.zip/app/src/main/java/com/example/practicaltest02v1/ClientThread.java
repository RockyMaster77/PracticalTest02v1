package com.example.practicaltest02v1;

import android.util.Log;
import android.widget.TextView;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

public class ClientThread extends Thread {
    private final String address;
    private final int port;
    private final String prefix;
    private final TextView resultTextView;

    public ClientThread(String address, int port, String prefix, TextView resultTextView) {
        this.address = address;
        this.port = port;
        this.prefix = prefix;
        this.resultTextView = resultTextView;
    }

    @Override
    public void run() {
        try {
            // 1. Deschidere conexiune către server
            Socket socket = new Socket(address, port);

            // 2. Trimitere prefix către server
            PrintWriter writer = new PrintWriter(socket.getOutputStream(), true);
            writer.println(prefix);
            Log.d("ClientThread", "Prefix trimis: " + prefix);


            // 3. Citire răspuns de la server
            BufferedReader reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            final String response = reader.readLine();

            // 4. Afișare în UI folosind post() (echivalent runOnUiThread)
            if (resultTextView != null) {
                resultTextView.post(() -> {
                    if (response != null) {
                        resultTextView.setText(response);
                    } else {
                        resultTextView.setText("Serverul a trimis un răspuns gol.");
                    }
                });
            }

            socket.close();

        } catch (IOException e) {
            Log.e("ClientThread", "Eroare conexiune: " + e.getMessage());
            if (resultTextView != null) {
                resultTextView.post(() -> resultTextView.setText("Eroare: " + e.getMessage()));
            }
        }
    }
}